# Nexus HQ — Full Stack Dashboard

React + Express + Prisma + PostgreSQL management dashboard with full CRUD.

---

## Prerequisites

Install these before starting:

- [Node.js 18+](https://nodejs.org/)
- [PostgreSQL 14+](https://www.postgresql.org/download/)

---

## 1. PostgreSQL Setup

### Option A — Local PostgreSQL (already installed)

Open **psql** or pgAdmin and run:

```sql
CREATE DATABASE nexus_dashboard;
```

### Option B — Docker (no local Postgres needed)

```bash
docker run --name nexus-pg \
  -e POSTGRES_PASSWORD=yourpassword \
  -e POSTGRES_DB=nexus_dashboard \
  -p 5432:5432 \
  -d postgres:16
```

---

## 2. Backend Setup

```bash
# Navigate to backend
cd nexus-dashboard/backend

# Install dependencies
npm install

# Copy and configure environment variables
cp .env.example .env
```

Open `.env` and set your database URL:

```
DATABASE_URL="postgresql://postgres:yourpassword@localhost:5432/nexus_dashboard"
PORT=5000
```

> Replace `yourpassword` with your actual PostgreSQL password.

```bash
# Run database migrations (creates tables)
npx prisma migrate dev --name init

# Seed the database with sample data
npm run db:seed

# Start the backend (development with auto-reload)
npm run dev
```

Backend will be running at: **http://localhost:5000**
Test it: **http://localhost:5000/api/health**

---

## 3. Frontend Setup

Open a **new terminal window/tab**:

```bash
# Navigate to frontend
cd nexus-dashboard/frontend

# Install dependencies
npm install

# Start the frontend dev server
npm run dev
```

Frontend will be running at: **http://localhost:5173**

---

## 4. Open in Browser

Go to: **http://localhost:5173**

---

## Project Structure

```
nexus-dashboard/
├── backend/
│   ├── prisma/
│   │   └── schema.prisma        # Database schema
│   ├── src/
│   │   ├── routes/
│   │   │   ├── users.js         # CRUD /api/users
│   │   │   ├── products.js      # CRUD /api/products
│   │   │   ├── orders.js        # CRUD /api/orders
│   │   │   └── stats.js         # GET  /api/stats
│   │   ├── index.js             # Express server
│   │   ├── prisma.js            # Prisma client
│   │   └── seed.js              # Sample data seeder
│   ├── .env.example
│   └── package.json
│
└── frontend/
    ├── src/
    │   ├── App.jsx              # Full dashboard UI
│   │   ├── api.js               # API service layer
    │   └── main.jsx             # React entry point
    ├── index.html
    ├── vite.config.js
    └── package.json
```

---

## API Endpoints

| Method | Endpoint            | Description         |
|--------|---------------------|---------------------|
| GET    | /api/health         | Health check        |
| GET    | /api/stats          | Dashboard stats     |
| GET    | /api/users          | List users          |
| POST   | /api/users          | Create user         |
| PUT    | /api/users/:id      | Update user         |
| DELETE | /api/users/:id      | Delete user         |
| GET    | /api/products       | List products       |
| POST   | /api/products       | Create product      |
| PUT    | /api/products/:id   | Update product      |
| DELETE | /api/products/:id   | Delete product      |
| GET    | /api/orders         | List orders         |
| POST   | /api/orders         | Create order        |
| PUT    | /api/orders/:id     | Update order        |
| DELETE | /api/orders/:id     | Delete order        |

---

## Useful Commands

```bash
# View/edit your database in a GUI
cd backend && npx prisma studio

# Re-seed the database
cd backend && npm run db:seed

# Reset database and re-migrate
cd backend && npx prisma migrate reset
```

---

## Troubleshooting

**"Can't connect to database"**
- Make sure PostgreSQL is running
- Double-check `DATABASE_URL` in `.env`
- Ensure the database `nexus_dashboard` exists

**"Port 5432 already in use"**
- Another Postgres instance is running. Stop it or change the port in `.env`

**Frontend shows API errors**
- Make sure the backend is running on port 5000
- Check the terminal running `npm run dev` in the backend folder
