require("dotenv").config();
const prisma = require("./prisma");

async function main() {
  console.log("🌱  Seeding database...");

  // Clear existing data
  await prisma.order.deleteMany();
  await prisma.product.deleteMany();
  await prisma.user.deleteMany();

  // ── Users ──────────────────────────────────────────────────────────────
  const users = await Promise.all([
    prisma.user.create({ data: { name: "Sofia Reyes",   email: "sofia@example.com",   role: "Admin",   status: "Active",   avatar: "SR" } }),
    prisma.user.create({ data: { name: "Marcus Lin",    email: "marcus@example.com",  role: "Manager", status: "Active",   avatar: "ML" } }),
    prisma.user.create({ data: { name: "Priya Nair",    email: "priya@example.com",   role: "Editor",  status: "Pending",  avatar: "PN" } }),
    prisma.user.create({ data: { name: "James Okafor",  email: "james@example.com",   role: "Viewer",  status: "Inactive", avatar: "JO" } }),
    prisma.user.create({ data: { name: "Elena Vasquez", email: "elena@example.com",   role: "Editor",  status: "Active",   avatar: "EV" } }),
  ]);
  console.log(`✅  Created ${users.length} users`);

  // ── Products ───────────────────────────────────────────────────────────
  const products = await Promise.all([
    prisma.product.create({ data: { name: "Astra Keyboard",      category: "Electronics", price: 149.99, stock: 240, status: "Active" } }),
    prisma.product.create({ data: { name: "Nimbus Hoodie",       category: "Apparel",     price: 79.00,  stock: 85,  status: "Active" } }),
    prisma.product.create({ data: { name: "CloudSync Pro",       category: "Software",    price: 299.00, stock: 999, status: "Active" } }),
    prisma.product.create({ data: { name: "Volta Charger",       category: "Hardware",    price: 59.99,  stock: 12,  status: "Low Stock" } }),
    prisma.product.create({ data: { name: "Grain Coffee Blend",  category: "Food",        price: 22.50,  stock: 0,   status: "Out of Stock" } }),
  ]);
  console.log(`✅  Created ${products.length} products`);

  // ── Orders ─────────────────────────────────────────────────────────────
  const orders = await Promise.all([
    prisma.order.create({ data: { customer: "Sofia Reyes",   productId: products[0].id, amount: 149.99, status: "Completed",  date: new Date("2025-05-10") } }),
    prisma.order.create({ data: { customer: "Marcus Lin",    productId: products[2].id, amount: 299.00, status: "Processing", date: new Date("2025-05-14") } }),
    prisma.order.create({ data: { customer: "Priya Nair",    productId: products[1].id, amount: 79.00,  status: "Shipped",    date: new Date("2025-05-16") } }),
    prisma.order.create({ data: { customer: "James Okafor",  productId: products[3].id, amount: 59.99,  status: "Cancelled",  date: new Date("2025-05-17") } }),
    prisma.order.create({ data: { customer: "Elena Vasquez", productId: products[4].id, amount: 22.50,  status: "Completed",  date: new Date("2025-05-18") } }),
  ]);
  console.log(`✅  Created ${orders.length} orders`);

  console.log("\n🎉  Seed complete!\n");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
