const router = require("express").Router();
const prisma = require("../prisma");

// Helper: derive avatar initials from name
const getAvatar = (name) =>
  name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

// GET /api/users — list all users
router.get("/", async (req, res, next) => {
  try {
    const { search, role, status } = req.query;
    const where = {};
    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } },
      ];
    }
    if (role) where.role = role;
    if (status) where.status = status;

    const users = await prisma.user.findMany({
      where,
      orderBy: { createdAt: "desc" },
    });
    res.json(users);
  } catch (err) {
    next(err);
  }
});

// GET /api/users/:id — get single user
router.get("/:id", async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.params.id } });
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json(user);
  } catch (err) {
    next(err);
  }
});

// POST /api/users — create user
router.post("/", async (req, res, next) => {
  try {
    const { name, email, role, status } = req.body;
    if (!name || !email) {
      return res.status(400).json({ error: "Name and email are required" });
    }
    const user = await prisma.user.create({
      data: {
        name,
        email,
        role: role || "Viewer",
        status: status || "Active",
        avatar: getAvatar(name),
      },
    });
    res.status(201).json(user);
  } catch (err) {
    if (err.code === "P2002") {
      return res.status(409).json({ error: "Email already exists" });
    }
    next(err);
  }
});

// PUT /api/users/:id — update user
router.put("/:id", async (req, res, next) => {
  try {
    const { name, email, role, status } = req.body;
    const data = {};
    if (name) { data.name = name; data.avatar = getAvatar(name); }
    if (email) data.email = email;
    if (role) data.role = role;
    if (status) data.status = status;

    const user = await prisma.user.update({
      where: { id: req.params.id },
      data,
    });
    res.json(user);
  } catch (err) {
    if (err.code === "P2025") return res.status(404).json({ error: "User not found" });
    next(err);
  }
});

// DELETE /api/users/:id — delete user
router.delete("/:id", async (req, res, next) => {
  try {
    await prisma.user.delete({ where: { id: req.params.id } });
    res.json({ message: "User deleted successfully" });
  } catch (err) {
    if (err.code === "P2025") return res.status(404).json({ error: "User not found" });
    next(err);
  }
});

module.exports = router;
