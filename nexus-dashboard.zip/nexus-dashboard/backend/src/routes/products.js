const router = require("express").Router();
const prisma = require("../prisma");

const getStockStatus = (stock) => {
  if (stock === 0) return "Out of Stock";
  if (stock < 20) return "Low Stock";
  return "Active";
};

// GET /api/products
router.get("/", async (req, res, next) => {
  try {
    const { search, category, status } = req.query;
    const where = {};
    if (search) where.name = { contains: search, mode: "insensitive" };
    if (category) where.category = category;
    if (status) where.status = status;

    const products = await prisma.product.findMany({
      where,
      orderBy: { createdAt: "desc" },
    });
    res.json(products);
  } catch (err) {
    next(err);
  }
});

// GET /api/products/:id
router.get("/:id", async (req, res, next) => {
  try {
    const product = await prisma.product.findUnique({
      where: { id: req.params.id },
      include: { orders: true },
    });
    if (!product) return res.status(404).json({ error: "Product not found" });
    res.json(product);
  } catch (err) {
    next(err);
  }
});

// POST /api/products
router.post("/", async (req, res, next) => {
  try {
    const { name, category, price, stock } = req.body;
    if (!name || price === undefined) {
      return res.status(400).json({ error: "Name and price are required" });
    }
    const stockVal = Number(stock) || 0;
    const product = await prisma.product.create({
      data: {
        name,
        category: category || "General",
        price: Number(price),
        stock: stockVal,
        status: getStockStatus(stockVal),
      },
    });
    res.status(201).json(product);
  } catch (err) {
    next(err);
  }
});

// PUT /api/products/:id
router.put("/:id", async (req, res, next) => {
  try {
    const { name, category, price, stock } = req.body;
    const data = {};
    if (name) data.name = name;
    if (category) data.category = category;
    if (price !== undefined) data.price = Number(price);
    if (stock !== undefined) {
      data.stock = Number(stock);
      data.status = getStockStatus(Number(stock));
    }

    const product = await prisma.product.update({
      where: { id: req.params.id },
      data,
    });
    res.json(product);
  } catch (err) {
    if (err.code === "P2025") return res.status(404).json({ error: "Product not found" });
    next(err);
  }
});

// DELETE /api/products/:id
router.delete("/:id", async (req, res, next) => {
  try {
    await prisma.product.delete({ where: { id: req.params.id } });
    res.json({ message: "Product deleted successfully" });
  } catch (err) {
    if (err.code === "P2025") return res.status(404).json({ error: "Product not found" });
    next(err);
  }
});

module.exports = router;
