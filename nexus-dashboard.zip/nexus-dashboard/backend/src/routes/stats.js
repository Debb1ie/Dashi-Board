const router = require("express").Router();
const prisma = require("../prisma");

// GET /api/stats — dashboard overview numbers
router.get("/", async (req, res, next) => {
  try {
    const [
      totalUsers,
      activeUsers,
      totalProducts,
      totalOrders,
      completedOrders,
      ordersByStatus,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { status: "Active" } }),
      prisma.product.count(),
      prisma.order.count(),
      prisma.order.findMany({ where: { status: "Completed" }, select: { amount: true } }),
      prisma.order.groupBy({ by: ["status"], _count: { id: true } }),
    ]);

    const revenue = completedOrders.reduce((sum, o) => sum + o.amount, 0);

    res.json({
      users: { total: totalUsers, active: activeUsers },
      products: { total: totalProducts },
      orders: {
        total: totalOrders,
        byStatus: ordersByStatus.reduce((acc, row) => {
          acc[row.status] = row._count.id;
          return acc;
        }, {}),
      },
      revenue,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
