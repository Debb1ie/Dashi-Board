const router = require("express").Router();
const prisma = require("../prisma");

// GET /api/orders
router.get("/", async (req, res, next) => {
  try {
    const { search, status } = req.query;
    const where = {};
    if (search) {
      where.OR = [
        { customer: { contains: search, mode: "insensitive" } },
        { product: { name: { contains: search, mode: "insensitive" } } },
      ];
    }
    if (status) where.status = status;

    const orders = await prisma.order.findMany({
      where,
      include: { product: { select: { id: true, name: true, category: true } } },
      orderBy: { createdAt: "desc" },
    });
    res.json(orders);
  } catch (err) {
    next(err);
  }
});

// GET /api/orders/:id
router.get("/:id", async (req, res, next) => {
  try {
    const order = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: { product: true },
    });
    if (!order) return res.status(404).json({ error: "Order not found" });
    res.json(order);
  } catch (err) {
    next(err);
  }
});

// POST /api/orders
router.post("/", async (req, res, next) => {
  try {
    const { customer, productId, amount, status, date } = req.body;
    if (!customer || amount === undefined) {
      return res.status(400).json({ error: "Customer and amount are required" });
    }
    const order = await prisma.order.create({
      data: {
        customer,
        amount: Number(amount),
        status: status || "Processing",
        date: date ? new Date(date) : new Date(),
        productId: productId || null,
      },
      include: { product: { select: { id: true, name: true } } },
    });
    res.status(201).json(order);
  } catch (err) {
    next(err);
  }
});

// PUT /api/orders/:id
router.put("/:id", async (req, res, next) => {
  try {
    const { customer, productId, amount, status, date } = req.body;
    const data = {};
    if (customer) data.customer = customer;
    if (productId !== undefined) data.productId = productId || null;
    if (amount !== undefined) data.amount = Number(amount);
    if (status) data.status = status;
    if (date) data.date = new Date(date);

    const order = await prisma.order.update({
      where: { id: req.params.id },
      data,
      include: { product: { select: { id: true, name: true } } },
    });
    res.json(order);
  } catch (err) {
    if (err.code === "P2025") return res.status(404).json({ error: "Order not found" });
    next(err);
  }
});

// DELETE /api/orders/:id
router.delete("/:id", async (req, res, next) => {
  try {
    await prisma.order.delete({ where: { id: req.params.id } });
    res.json({ message: "Order deleted successfully" });
  } catch (err) {
    if (err.code === "P2025") return res.status(404).json({ error: "Order not found" });
    next(err);
  }
});

module.exports = router;
