const BASE = "/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || "Request failed");
  }
  return res.json();
}

// ── Users ──────────────────────────────────────────────────────────────────
export const api = {
  // Stats
  getStats: () => request("/stats"),

  // Users
  getUsers: (params = {}) => request("/users?" + new URLSearchParams(params)),
  getUser: (id) => request(`/users/${id}`),
  createUser: (data) => request("/users", { method: "POST", body: data }),
  updateUser: (id, data) => request(`/users/${id}`, { method: "PUT", body: data }),
  deleteUser: (id) => request(`/users/${id}`, { method: "DELETE" }),

  // Products
  getProducts: (params = {}) => request("/products?" + new URLSearchParams(params)),
  getProduct: (id) => request(`/products/${id}`),
  createProduct: (data) => request("/products", { method: "POST", body: data }),
  updateProduct: (id, data) => request(`/products/${id}`, { method: "PUT", body: data }),
  deleteProduct: (id) => request(`/products/${id}`, { method: "DELETE" }),

  // Orders
  getOrders: (params = {}) => request("/orders?" + new URLSearchParams(params)),
  getOrder: (id) => request(`/orders/${id}`),
  createOrder: (data) => request("/orders", { method: "POST", body: data }),
  updateOrder: (id, data) => request(`/orders/${id}`, { method: "PUT", body: data }),
  deleteOrder: (id) => request(`/orders/${id}`, { method: "DELETE" }),
};
