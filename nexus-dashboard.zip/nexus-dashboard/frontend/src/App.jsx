import { useState, useEffect, useCallback, useRef } from "react";
import { api } from "./api.js";

// ── Tiny icon helper ───────────────────────────────────────────────────────
const Icon = ({ d, size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);
const IC = {
  dashboard: "M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z",
  users: "M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zm14 10v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75",
  products: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4",
  orders: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2",
  analytics: "M18 20V10M12 20V4M6 20v-6",
  settings: "M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z",
  plus: "M12 5v14M5 12h14",
  edit: "M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z",
  trash: "M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6",
  search: "M21 21l-4.35-4.35M17 11A6 6 0 105 11a6 6 0 0012 0z",
  close: "M18 6L6 18M6 6l12 12",
  check: "M20 6L9 17l-5-5",
  bell: "M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0",
  menu: "M3 12h18M3 6h18M3 18h18",
  refresh: "M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15",
  alert: "M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0zM12 9v4M12 17h.01",
};

// ── Helpers ────────────────────────────────────────────────────────────────
const statusColor = (s) => ({
  Active: "#22c55e", Completed: "#22c55e",
  Pending: "#f59e0b", Processing: "#f59e0b", Shipped: "#3b82f6",
  Inactive: "#94a3b8", Cancelled: "#ef4444",
  "Low Stock": "#f59e0b", "Out of Stock": "#ef4444",
}[s] || "#94a3b8");

const fmt = (n) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n ?? 0);

// ── useData hook ───────────────────────────────────────────────────────────
function useData(fetcher, deps = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetcher();
      setData(result);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, deps);

  useEffect(() => { load(); }, [load]);
  return { data, loading, error, reload: load };
}

// ── Toast ──────────────────────────────────────────────────────────────────
function Toast({ msg, type = "success", onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 2800); return () => clearTimeout(t); }, []);
  const bg = type === "error" ? "#ef4444" : "var(--accent)";
  return (
    <div style={{ position: "fixed", bottom: 28, right: 28, background: bg, color: "#fff", padding: "12px 20px", borderRadius: 10, fontSize: 14, fontWeight: 500, display: "flex", alignItems: "center", gap: 8, zIndex: 9999, boxShadow: "0 8px 32px rgba(0,0,0,.3)", animation: "slideUp .25s ease" }}>
      <Icon d={type === "error" ? IC.alert : IC.check} size={16} />{msg}
    </div>
  );
}

// ── Modal ──────────────────────────────────────────────────────────────────
function Modal({ title, onClose, children }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000 }}>
      <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 16, padding: 32, width: "min(520px,94vw)", maxHeight: "90vh", overflowY: "auto", boxShadow: "0 32px 80px rgba(0,0,0,.45)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <h2 style={{ margin: 0, fontSize: 18, fontFamily: "var(--font-head)", color: "var(--text)" }}>{title}</h2>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--muted)", padding: 4, borderRadius: 6 }}><Icon d={IC.close} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Field({ label, type = "text", value, onChange, options, required }) {
  const base = { width: "100%", padding: "10px 12px", background: "var(--input-bg)", border: "1px solid var(--border)", borderRadius: 8, color: "var(--text)", fontSize: 14, fontFamily: "var(--font-body)", boxSizing: "border-box", outline: "none" };
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ display: "block", marginBottom: 6, fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: ".08em", color: "var(--muted)" }}>{label}{required && " *"}</label>
      {options
        ? <select value={value} onChange={e => onChange(e.target.value)} style={base}>{options.map(o => <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>)}</select>
        : <input type={type} value={value} onChange={e => onChange(e.target.value)} style={base} />}
    </div>
  );
}

function ConfirmDelete({ name, onConfirm, onCancel, loading }) {
  return (
    <Modal title="Confirm Delete" onClose={onCancel}>
      <p style={{ color: "var(--muted)", marginBottom: 24, lineHeight: 1.6 }}>Are you sure you want to delete <strong style={{ color: "var(--text)" }}>{name}</strong>? This cannot be undone.</p>
      <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
        <Btn label="Cancel" onClick={onCancel} variant="ghost" />
        <Btn label={loading ? "Deleting…" : "Delete"} onClick={onConfirm} variant="danger" disabled={loading} />
      </div>
    </Modal>
  );
}

function Btn({ label, onClick, variant = "primary", icon, disabled }) {
  const styles = {
    primary: { background: "var(--accent)", color: "#fff", border: "none" },
    ghost: { background: "var(--input-bg)", color: "var(--text)", border: "1px solid var(--border)" },
    danger: { background: "#ef4444", color: "#fff", border: "none" },
  };
  return (
    <button onClick={onClick} disabled={disabled} style={{ display: "flex", alignItems: "center", gap: 6, padding: "9px 16px", borderRadius: 8, cursor: disabled ? "not-allowed" : "pointer", fontSize: 13, fontWeight: 600, fontFamily: "var(--font-body)", opacity: disabled ? .6 : 1, transition: "opacity .15s", ...styles[variant] }}>
      {icon && <Icon d={icon} size={15} />}{label}
    </button>
  );
}

function Spinner() {
  return <div style={{ display: "flex", justifyContent: "center", padding: 48, color: "var(--muted)", fontSize: 14 }}>Loading…</div>;
}

function ErrorMsg({ msg, onRetry }) {
  return (
    <div style={{ padding: 24, background: "#ef444422", border: "1px solid #ef4444", borderRadius: 12, color: "#ef4444", display: "flex", alignItems: "center", gap: 12 }}>
      <Icon d={IC.alert} size={18} />
      <span style={{ flex: 1 }}>{msg}</span>
      {onRetry && <button onClick={onRetry} style={{ background: "none", border: "1px solid #ef4444", borderRadius: 7, padding: "5px 12px", color: "#ef4444", cursor: "pointer", fontSize: 13 }}>Retry</button>}
    </div>
  );
}

function Table({ cols, rows, onEdit, onDelete }) {
  return (
    <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, overflow: "hidden" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
        <thead><tr style={{ borderBottom: "1px solid var(--border)" }}>
          {cols.map(c => <th key={c.key} style={{ padding: "13px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".06em", color: "var(--muted)", whiteSpace: "nowrap" }}>{c.label}</th>)}
          <th style={{ padding: "13px 16px", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".06em", color: "var(--muted)" }}>Actions</th>
        </tr></thead>
        <tbody>
          {rows.length === 0 && (
            <tr><td colSpan={cols.length + 1} style={{ padding: 32, textAlign: "center", color: "var(--muted)" }}>No records found</td></tr>
          )}
          {rows.map((row, i) => (
            <tr key={row.id} style={{ borderBottom: i < rows.length - 1 ? "1px solid var(--border)" : "none" }}
              onMouseEnter={e => e.currentTarget.style.background = "var(--hover)"}
              onMouseLeave={e => e.currentTarget.style.background = ""}>
              {cols.map(c => <td key={c.key} style={{ padding: "13px 16px", color: "var(--text)" }}>{c.render ? c.render(row) : row[c.key]}</td>)}
              <td style={{ padding: "13px 16px" }}>
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={() => onEdit(row)} style={{ background: "none", border: "1px solid var(--border)", borderRadius: 7, padding: "5px 8px", cursor: "pointer", color: "var(--muted)" }}><Icon d={IC.edit} size={14} /></button>
                  <button onClick={() => onDelete(row)} style={{ background: "none", border: "1px solid var(--border)", borderRadius: 7, padding: "5px 8px", cursor: "pointer", color: "#ef4444" }}><Icon d={IC.trash} size={14} /></button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function StatusBadge({ status }) {
  return <span style={{ padding: "4px 10px", borderRadius: 99, fontSize: 12, fontWeight: 600, background: statusColor(status) + "22", color: statusColor(status), whiteSpace: "nowrap" }}>{status}</span>;
}

function SectionHeader({ title, search, onSearch, onCreate, createLabel }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
      <h2 style={{ fontFamily: "var(--font-head)", fontSize: 22, color: "var(--text)", margin: 0 }}>{title}</h2>
      <div style={{ display: "flex", gap: 10 }}>
        {onSearch && (
          <div style={{ position: "relative" }}>
            <span style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--muted)", pointerEvents: "none" }}><Icon d={IC.search} size={15} /></span>
            <input value={search} onChange={e => onSearch(e.target.value)} placeholder={`Search ${title.toLowerCase()}…`}
              style={{ paddingLeft: 32, padding: "9px 12px 9px 32px", background: "var(--input-bg)", border: "1px solid var(--border)", borderRadius: 8, color: "var(--text)", fontSize: 13, outline: "none", width: 210, fontFamily: "var(--font-body)" }} />
          </div>
        )}
        <Btn label={createLabel || `Add ${title.slice(0,-1)}`} onClick={onCreate} icon={IC.plus} />
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// Dashboard
// ══════════════════════════════════════════════════════════════════════════
function StatCard({ label, value, sub, icon, color }) {
  return (
    <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, padding: "22px 24px", display: "flex", alignItems: "flex-start", gap: 16, flex: "1 1 170px" }}>
      <div style={{ width: 44, height: 44, borderRadius: 12, background: color + "22", display: "flex", alignItems: "center", justifyContent: "center", color, flexShrink: 0 }}><Icon d={icon} size={20} /></div>
      <div>
        <div style={{ fontSize: 26, fontWeight: 700, fontFamily: "var(--font-head)", color: "var(--text)", lineHeight: 1.1 }}>{value}</div>
        <div style={{ fontSize: 13, color: "var(--muted)", marginTop: 2 }}>{label}</div>
        {sub && <div style={{ fontSize: 11, color, marginTop: 4, fontWeight: 600 }}>{sub}</div>}
      </div>
    </div>
  );
}

function MiniBar({ label, value, max, color }) {
  const pct = max > 0 ? (value / max) * 100 : 0;
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5, fontSize: 13 }}>
        <span style={{ color: "var(--text)" }}>{label}</span>
        <span style={{ color: "var(--muted)" }}>{value}</span>
      </div>
      <div style={{ height: 6, background: "var(--border)", borderRadius: 99, overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${pct}%`, background: color, borderRadius: 99, transition: "width .8s ease" }} />
      </div>
    </div>
  );
}

function DashboardSection({ toast }) {
  const { data: stats, loading, error, reload } = useData(() => api.getStats());
  const { data: products } = useData(() => api.getProducts());

  if (loading) return <Spinner />;
  if (error) return <ErrorMsg msg={error} onRetry={reload} />;
  if (!stats) return null;

  const statusLabels = ["Completed", "Processing", "Shipped", "Cancelled"];
  const maxStatus = Math.max(...statusLabels.map(s => stats.orders.byStatus[s] || 0), 1);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <h2 style={{ fontFamily: "var(--font-head)", fontSize: 22, color: "var(--text)" }}>Overview</h2>
        <button onClick={reload} style={{ background: "none", border: "1px solid var(--border)", borderRadius: 8, padding: "7px 10px", cursor: "pointer", color: "var(--muted)", display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}>
          <Icon d={IC.refresh} size={14} /> Refresh
        </button>
      </div>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 28 }}>
        <StatCard label="Total Users" value={stats.users.total} sub={`${stats.users.active} active`} icon={IC.users} color="#6366f1" />
        <StatCard label="Products" value={stats.products.total} sub="in catalog" icon={IC.products} color="#0ea5e9" />
        <StatCard label="Orders" value={stats.orders.total} sub={`${stats.orders.byStatus.Processing || 0} processing`} icon={IC.orders} color="#f59e0b" />
        <StatCard label="Revenue" value={fmt(stats.revenue)} sub="from completed orders" icon={IC.analytics} color="#22c55e" />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px,1fr))", gap: 20, maxWidth: 800 }}>
        <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, padding: 24 }}>
          <h3 style={{ fontFamily: "var(--font-head)", fontSize: 13, marginBottom: 20, color: "var(--muted)", textTransform: "uppercase", letterSpacing: ".06em" }}>Order Status</h3>
          {statusLabels.map(s => <MiniBar key={s} label={s} value={stats.orders.byStatus[s] || 0} max={maxStatus} color={statusColor(s)} />)}
        </div>
        {products && (
          <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, padding: 24 }}>
            <h3 style={{ fontFamily: "var(--font-head)", fontSize: 13, marginBottom: 20, color: "var(--muted)", textTransform: "uppercase", letterSpacing: ".06em" }}>Product Stock</h3>
            {products.slice(0, 6).map(p => <MiniBar key={p.id} label={p.name} value={p.stock} max={Math.max(...products.map(x => x.stock), 1)} color="#0ea5e9" />)}
          </div>
        )}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// Users
// ══════════════════════════════════════════════════════════════════════════
const ROLES = ["Admin", "Manager", "Editor", "Viewer"];
const STATUS_USER = ["Active", "Inactive", "Pending"];

function UserForm({ initial, onSave, onClose }) {
  const blank = { name: "", email: "", role: "Viewer", status: "Active" };
  const [form, setForm] = useState(initial || blank);
  const [saving, setSaving] = useState(false);
  const set = k => v => setForm(f => ({ ...f, [k]: v }));
  const handleSave = async () => {
    if (!form.name || !form.email) return;
    setSaving(true);
    await onSave(form);
    setSaving(false);
  };
  return (
    <Modal title={initial ? "Edit User" : "Add User"} onClose={onClose}>
      <Field label="Full Name" value={form.name} onChange={set("name")} required />
      <Field label="Email" type="email" value={form.email} onChange={set("email")} required />
      <Field label="Role" value={form.role} onChange={set("role")} options={ROLES} />
      <Field label="Status" value={form.status} onChange={set("status")} options={STATUS_USER} />
      <div style={{ display: "flex", gap: 12, justifyContent: "flex-end", marginTop: 8 }}>
        <Btn label="Cancel" onClick={onClose} variant="ghost" />
        <Btn label={saving ? "Saving…" : (initial ? "Save Changes" : "Add User")} onClick={handleSave} disabled={saving || !form.name || !form.email} />
      </div>
    </Modal>
  );
}

function UsersSection({ toast }) {
  const [search, setSearch] = useState("");
  const { data: users, loading, error, reload } = useData(() => api.getUsers(search ? { search } : {}), [search]);
  const [modal, setModal] = useState(null);
  const [del, setDel] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const handleCreate = async (data) => {
    try { await api.createUser(data); toast("User created!"); setModal(null); reload(); }
    catch (e) { toast(e.message, "error"); }
  };
  const handleUpdate = async (data) => {
    try { await api.updateUser(data.id, data); toast("User updated!"); setModal(null); reload(); }
    catch (e) { toast(e.message, "error"); }
  };
  const handleDelete = async () => {
    setDeleting(true);
    try { await api.deleteUser(del.id); toast("User deleted."); setDel(null); reload(); }
    catch (e) { toast(e.message, "error"); }
    finally { setDeleting(false); }
  };

  const cols = [
    { key: "name", label: "User", render: u => (
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ width: 34, height: 34, borderRadius: "50%", background: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#fff", flexShrink: 0 }}>{u.avatar}</div>
        <div><div style={{ fontWeight: 600, color: "var(--text)" }}>{u.name}</div><div style={{ fontSize: 12, color: "var(--muted)" }}>{u.email}</div></div>
      </div>
    )},
    { key: "role", label: "Role", render: u => <span style={{ color: "var(--muted)" }}>{u.role}</span> },
    { key: "status", label: "Status", render: u => <StatusBadge status={u.status} /> },
    { key: "joined", label: "Joined", render: u => <span style={{ color: "var(--muted)", fontSize: 13 }}>{new Date(u.joined).toLocaleDateString()}</span> },
  ];

  return (
    <div>
      <SectionHeader title="Users" search={search} onSearch={setSearch} onCreate={() => setModal({ mode: "create" })} />
      {loading ? <Spinner /> : error ? <ErrorMsg msg={error} onRetry={reload} /> : <Table cols={cols} rows={users || []} onEdit={u => setModal({ mode: "edit", data: u })} onDelete={setDel} />}
      {modal?.mode === "create" && <UserForm onClose={() => setModal(null)} onSave={handleCreate} />}
      {modal?.mode === "edit" && <UserForm initial={modal.data} onClose={() => setModal(null)} onSave={d => handleUpdate({ ...modal.data, ...d })} />}
      {del && <ConfirmDelete name={del.name} loading={deleting} onCancel={() => setDel(null)} onConfirm={handleDelete} />}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// Products
// ══════════════════════════════════════════════════════════════════════════
const CATEGORIES = ["Electronics", "Apparel", "Food", "Software", "Hardware", "General"];

function ProductForm({ initial, onSave, onClose }) {
  const blank = { name: "", category: "Electronics", price: "", stock: "" };
  const [form, setForm] = useState(initial ? { ...initial, price: String(initial.price), stock: String(initial.stock) } : blank);
  const [saving, setSaving] = useState(false);
  const set = k => v => setForm(f => ({ ...f, [k]: v }));
  const handleSave = async () => {
    if (!form.name || !form.price) return;
    setSaving(true);
    await onSave({ ...form, price: Number(form.price), stock: Number(form.stock || 0) });
    setSaving(false);
  };
  return (
    <Modal title={initial ? "Edit Product" : "Add Product"} onClose={onClose}>
      <Field label="Product Name" value={form.name} onChange={set("name")} required />
      <Field label="Category" value={form.category} onChange={set("category")} options={CATEGORIES} />
      <Field label="Price (USD)" type="number" value={form.price} onChange={set("price")} required />
      <Field label="Stock Quantity" type="number" value={form.stock} onChange={set("stock")} />
      <div style={{ display: "flex", gap: 12, justifyContent: "flex-end", marginTop: 8 }}>
        <Btn label="Cancel" onClick={onClose} variant="ghost" />
        <Btn label={saving ? "Saving…" : (initial ? "Save Changes" : "Add Product")} onClick={handleSave} disabled={saving || !form.name || !form.price} />
      </div>
    </Modal>
  );
}

function ProductsSection({ toast }) {
  const [search, setSearch] = useState("");
  const { data: products, loading, error, reload } = useData(() => api.getProducts(search ? { search } : {}), [search]);
  const [modal, setModal] = useState(null);
  const [del, setDel] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const handleCreate = async (data) => {
    try { await api.createProduct(data); toast("Product created!"); setModal(null); reload(); }
    catch (e) { toast(e.message, "error"); }
  };
  const handleUpdate = async (data) => {
    try { await api.updateProduct(data.id, data); toast("Product updated!"); setModal(null); reload(); }
    catch (e) { toast(e.message, "error"); }
  };
  const handleDelete = async () => {
    setDeleting(true);
    try { await api.deleteProduct(del.id); toast("Product deleted."); setDel(null); reload(); }
    catch (e) { toast(e.message, "error"); }
    finally { setDeleting(false); }
  };

  const cols = [
    { key: "name", label: "Product", render: p => <span style={{ fontWeight: 600 }}>{p.name}</span> },
    { key: "category", label: "Category", render: p => <span style={{ color: "var(--muted)" }}>{p.category}</span> },
    { key: "price", label: "Price", render: p => <span style={{ fontFamily: "var(--font-mono)" }}>{fmt(p.price)}</span> },
    { key: "stock", label: "Stock", render: p => <span style={{ color: p.stock < 20 ? "#f59e0b" : "var(--muted)" }}>{p.stock}</span> },
    { key: "status", label: "Status", render: p => <StatusBadge status={p.status} /> },
  ];

  return (
    <div>
      <SectionHeader title="Products" search={search} onSearch={setSearch} onCreate={() => setModal({ mode: "create" })} />
      {loading ? <Spinner /> : error ? <ErrorMsg msg={error} onRetry={reload} /> : <Table cols={cols} rows={products || []} onEdit={p => setModal({ mode: "edit", data: p })} onDelete={setDel} />}
      {modal?.mode === "create" && <ProductForm onClose={() => setModal(null)} onSave={handleCreate} />}
      {modal?.mode === "edit" && <ProductForm initial={modal.data} onClose={() => setModal(null)} onSave={d => handleUpdate({ ...modal.data, ...d })} />}
      {del && <ConfirmDelete name={del.name} loading={deleting} onCancel={() => setDel(null)} onConfirm={handleDelete} />}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// Orders
// ══════════════════════════════════════════════════════════════════════════
const STATUS_ORDER = ["Processing", "Shipped", "Completed", "Cancelled"];

function OrderForm({ initial, onSave, onClose }) {
  const { data: products } = useData(() => api.getProducts());
  const blank = { customer: "", productId: "", amount: "", status: "Processing", date: new Date().toISOString().slice(0, 10) };
  const [form, setForm] = useState(initial
    ? { ...initial, productId: initial.productId || "", amount: String(initial.amount), date: new Date(initial.date).toISOString().slice(0, 10) }
    : blank);
  const [saving, setSaving] = useState(false);
  const set = k => v => setForm(f => ({ ...f, [k]: v }));
  const productOptions = [{ value: "", label: "— No product —" }, ...(products || []).map(p => ({ value: p.id, label: p.name }))];
  const handleSave = async () => {
    if (!form.customer || !form.amount) return;
    setSaving(true);
    await onSave({ ...form, amount: Number(form.amount), productId: form.productId || null });
    setSaving(false);
  };
  return (
    <Modal title={initial ? "Edit Order" : "New Order"} onClose={onClose}>
      <Field label="Customer Name" value={form.customer} onChange={set("customer")} required />
      <Field label="Product" value={form.productId} onChange={set("productId")} options={productOptions} />
      <Field label="Amount (USD)" type="number" value={form.amount} onChange={set("amount")} required />
      <Field label="Status" value={form.status} onChange={set("status")} options={STATUS_ORDER} />
      <Field label="Date" type="date" value={form.date} onChange={set("date")} />
      <div style={{ display: "flex", gap: 12, justifyContent: "flex-end", marginTop: 8 }}>
        <Btn label="Cancel" onClick={onClose} variant="ghost" />
        <Btn label={saving ? "Saving…" : (initial ? "Save Changes" : "Create Order")} onClick={handleSave} disabled={saving || !form.customer || !form.amount} />
      </div>
    </Modal>
  );
}

function OrdersSection({ toast }) {
  const [search, setSearch] = useState("");
  const { data: orders, loading, error, reload } = useData(() => api.getOrders(search ? { search } : {}), [search]);
  const [modal, setModal] = useState(null);
  const [del, setDel] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const handleCreate = async (data) => {
    try { await api.createOrder(data); toast("Order created!"); setModal(null); reload(); }
    catch (e) { toast(e.message, "error"); }
  };
  const handleUpdate = async (data) => {
    try { await api.updateOrder(data.id, data); toast("Order updated!"); setModal(null); reload(); }
    catch (e) { toast(e.message, "error"); }
  };
  const handleDelete = async () => {
    setDeleting(true);
    try { await api.deleteOrder(del.id); toast("Order deleted."); setDel(null); reload(); }
    catch (e) { toast(e.message, "error"); }
    finally { setDeleting(false); }
  };

  const cols = [
    { key: "customer", label: "Customer", render: o => <span style={{ fontWeight: 600 }}>{o.customer}</span> },
    { key: "product", label: "Product", render: o => <span style={{ color: "var(--muted)" }}>{o.product?.name || "—"}</span> },
    { key: "amount", label: "Amount", render: o => <span style={{ fontFamily: "var(--font-mono)" }}>{fmt(o.amount)}</span> },
    { key: "status", label: "Status", render: o => <StatusBadge status={o.status} /> },
    { key: "date", label: "Date", render: o => <span style={{ color: "var(--muted)", fontSize: 13 }}>{new Date(o.date).toLocaleDateString()}</span> },
  ];

  return (
    <div>
      <SectionHeader title="Orders" search={search} onSearch={setSearch} onCreate={() => setModal({ mode: "create" })} createLabel="New Order" />
      {loading ? <Spinner /> : error ? <ErrorMsg msg={error} onRetry={reload} /> : <Table cols={cols} rows={orders || []} onEdit={o => setModal({ mode: "edit", data: o })} onDelete={setDel} />}
      {modal?.mode === "create" && <OrderForm onClose={() => setModal(null)} onSave={handleCreate} />}
      {modal?.mode === "edit" && <OrderForm initial={modal.data} onClose={() => setModal(null)} onSave={d => handleUpdate({ ...modal.data, ...d })} />}
      {del && <ConfirmDelete name={`order by ${del.customer}`} loading={deleting} onCancel={() => setDel(null)} onConfirm={handleDelete} />}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// APP ROOT
// ══════════════════════════════════════════════════════════════════════════
const NAV = [
  { id: "dashboard", label: "Dashboard", icon: IC.dashboard },
  { id: "users", label: "Users", icon: IC.users },
  { id: "products", label: "Products", icon: IC.products },
  { id: "orders", label: "Orders", icon: IC.orders },
  { id: "settings", label: "Settings", icon: IC.settings },
];

export default function App() {
  const [active, setActive] = useState("dashboard");
  const [toast, setToast] = useState(null);
  const [sidebar, setSidebar] = useState(true);
  const [dark, setDark] = useState(true);

  const showToast = useCallback((msg, type = "success") => setToast({ msg, type }), []);

  const theme = dark ? {
    "--bg": "#0d0f14", "--surface": "#161920", "--border": "#252830",
    "--text": "#e8eaf0", "--muted": "#5a6070", "--accent": "#6366f1",
    "--input-bg": "#1e2128", "--hover": "#1c1f27",
  } : {
    "--bg": "#f4f5f8", "--surface": "#ffffff", "--border": "#e2e5ec",
    "--text": "#1a1d26", "--muted": "#7c8596", "--accent": "#6366f1",
    "--input-bg": "#f0f1f5", "--hover": "#f8f9fb",
  };

  const cssVars = {
    ...theme,
    "--font-head": "'DM Serif Display', Georgia, serif",
    "--font-body": "'DM Sans', system-ui, sans-serif",
    "--font-mono": "'JetBrains Mono', monospace",
  };

  return (
    <>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: var(--bg); color: var(--text); font-family: var(--font-body); }
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
        input, select, button { font-family: var(--font-body); }
        @keyframes slideUp { from { opacity:0; transform:translateY(14px); } to { opacity:1; transform:translateY(0); } }
        input[type=number]::-webkit-inner-spin-button { -webkit-appearance: none; }
        input[type=date]::-webkit-calendar-picker-indicator { filter: ${dark ? "invert(1)" : "none"}; }
      `}</style>
      <div style={{ display: "flex", height: "100vh", overflow: "hidden", ...cssVars }}>

        {/* ── Sidebar ── */}
        <aside style={{ width: sidebar ? 224 : 62, flexShrink: 0, background: "var(--surface)", borderRight: "1px solid var(--border)", display: "flex", flexDirection: "column", transition: "width .28s cubic-bezier(.4,0,.2,1)", overflow: "hidden" }}>
          <div style={{ padding: "18px 14px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 10, minHeight: 62 }}>
            <div style={{ width: 32, height: 32, borderRadius: 9, background: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 13, fontWeight: 800, color: "#fff", letterSpacing: "-.5px" }}>N</div>
            {sidebar && <span style={{ fontFamily: "var(--font-head)", fontSize: 17, color: "var(--text)", whiteSpace: "nowrap" }}>Nexus HQ</span>}
          </div>
          <nav style={{ flex: 1, padding: "10px 8px", overflowY: "auto" }}>
            {NAV.map(n => {
              const on = active === n.id;
              return (
                <button key={n.id} onClick={() => setActive(n.id)}
                  style={{ display: "flex", alignItems: "center", gap: 11, padding: sidebar ? "10px 12px" : "10px", width: "100%", border: "none", borderRadius: 9, cursor: "pointer", marginBottom: 2, transition: "background .12s", background: on ? "var(--accent)" : "none", color: on ? "#fff" : "var(--muted)", fontSize: 13.5, fontWeight: on ? 600 : 400, whiteSpace: "nowrap", justifyContent: sidebar ? "flex-start" : "center" }}
                  onMouseEnter={e => { if (!on) e.currentTarget.style.background = "var(--hover)"; }}
                  onMouseLeave={e => { if (!on) e.currentTarget.style.background = "none"; }}>
                  <Icon d={n.icon} size={17} />{sidebar && n.label}
                </button>
              );
            })}
          </nav>
          <div style={{ padding: "10px 8px", borderTop: "1px solid var(--border)" }}>
            {sidebar && (
              <div style={{ display: "flex", alignItems: "center", gap: 9, padding: "8px 12px", marginBottom: 4 }}>
                <div style={{ width: 30, height: 30, borderRadius: "50%", background: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: "#fff", flexShrink: 0 }}>AD</div>
                <div><div style={{ fontSize: 12.5, fontWeight: 600, color: "var(--text)" }}>Admin User</div><div style={{ fontSize: 11, color: "var(--muted)" }}>Administrator</div></div>
              </div>
            )}
            <button onClick={() => setDark(!dark)} style={{ display: "flex", alignItems: "center", gap: 10, padding: sidebar ? "8px 12px" : "8px", width: "100%", border: "none", borderRadius: 8, cursor: "pointer", background: "none", color: "var(--muted)", fontSize: 12.5, justifyContent: sidebar ? "flex-start" : "center" }}>
              <span style={{ fontSize: 15 }}>{dark ? "☀️" : "🌙"}</span>{sidebar && (dark ? "Light Mode" : "Dark Mode")}
            </button>
          </div>
        </aside>

        {/* ── Main ── */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>
          <header style={{ height: 62, borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", padding: "0 22px", gap: 14, background: "var(--surface)", flexShrink: 0 }}>
            <button onClick={() => setSidebar(s => !s)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--muted)", padding: 4, borderRadius: 6, display: "flex" }}><Icon d={IC.menu} size={19} /></button>
            <div style={{ flex: 1 }} />
            <span style={{ fontSize: 12.5, color: "var(--muted)" }}>{new Date().toDateString()}</span>
            <div style={{ width: 1, height: 20, background: "var(--border)" }} />
            <button style={{ background: "none", border: "1px solid var(--border)", borderRadius: 8, padding: "6px 8px", cursor: "pointer", color: "var(--muted)", position: "relative", display: "flex" }}>
              <Icon d={IC.bell} size={15} />
              <span style={{ position: "absolute", top: 4, right: 4, width: 6, height: 6, background: "#ef4444", borderRadius: "50%", border: "2px solid var(--surface)" }} />
            </button>
          </header>
          <main style={{ flex: 1, overflowY: "auto", padding: "28px 28px 40px" }}>
            {active === "dashboard" && <DashboardSection toast={showToast} />}
            {active === "users" && <UsersSection toast={showToast} />}
            {active === "products" && <ProductsSection toast={showToast} />}
            {active === "orders" && <OrdersSection toast={showToast} />}
            {active === "settings" && (
              <div>
                <h2 style={{ fontFamily: "var(--font-head)", fontSize: 22, color: "var(--text)", marginBottom: 24 }}>Settings</h2>
                <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, padding: 28, maxWidth: 500 }}>
                  <p style={{ color: "var(--muted)", fontSize: 14, lineHeight: 1.7, marginBottom: 20 }}>
                    Configure your system preferences, manage integrations, and control account settings here.
                    Toggle between dark/light mode using the button in the sidebar footer.
                  </p>
                  <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                    {["General", "Security", "Billing", "Notifications", "Integrations"].map(tab => (
                      <button key={tab} style={{ padding: "8px 16px", background: "var(--input-bg)", border: "1px solid var(--border)", borderRadius: 8, color: "var(--muted)", cursor: "pointer", fontSize: 13 }}>{tab}</button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </main>
        </div>

        {toast && <Toast msg={toast.msg} type={toast.type} onDone={() => setToast(null)} />}
      </div>
    </>
  );
}
